#include "net/rpl/rpl.h"
#include "net/rpl/rpl-private.h"
#include "net/link-stats.h"
#include "net/ipv6/uip-ds6.h"
#include "sys/clock.h"
#include "drl_agent.h"
#include <stdio.h>

#ifndef RPL_DAG_MC_ETX_DIVISOR
#define RPL_DAG_MC_ETX_DIVISOR 128
#endif

/* ====== Globals sent in DIO PE option ====== */
uint16_t rpl_pe_E = 0;
uint16_t rpl_pe_InvV = 0;
uint16_t rpl_pe_Deg = 0;
uint16_t rpl_pe_Stb = 0;
uint16_t rpl_pe_TauTx = 0;

/* ====== Tau weights (tunable) ====== */
#define TAU_ALPHA 4
#define TAU_BETA  3
#define TAU_GAMMA 2
#define TAU_DELTA 3
#define TAU_PSI   5

/* ====== Parent switch counter (for stability) ====== */
static volatile uint16_t parent_switches = 0;

/* Called from rpl-dag.c when preferred parent switches */
void rpl_of_drl_on_parent_switch(void) { parent_switches++; }

/* ====== Weak hooks to provide real metrics (override in your app) ====== */
__attribute__((weak)) uint16_t rpl_residual_energy_norm(void) { return 1000; } /* 0..1000 */
__attribute__((weak)) uint16_t rpl_inv_speed_norm(void) { return 800; }        /* 0..1000 */

/* ====== Helpers ====== */
static uint16_t clamp1000(uint16_t v) { return v > 1000 ? 1000 : v; }

static uint16_t node_degree_norm(void)
{
  uint8_t deg = 0;
  uip_ds6_nbr_t *nbr = uip_ds6_nbr_head();
  while(nbr != NULL) { deg++; nbr = uip_ds6_nbr_next(nbr); }
  if(deg >= 20) return 1000;
  return (uint16_t)((uint32_t)deg * 1000UL / 20);
}

static uint16_t stability_norm(void)
{
  /* 1/(1+switches) mapped */
  uint16_t s = parent_switches;
  if(s >= 999) return 1;
  return (uint16_t)(1000U / (1U + s));
}

/* Compute tau_candidate from received PE parameters (0..1000) */
uint16_t rpl_of_drl_tau_candidate(rpl_parent_t *p)
{
  uint32_t wsum = (TAU_ALPHA + TAU_BETA + TAU_GAMMA + TAU_DELTA + TAU_PSI);
  uint32_t num =
    (uint32_t)TAU_ALPHA * clamp1000(p->pe_E) +
    (uint32_t)TAU_BETA  * clamp1000(p->pe_InvV) +
    (uint32_t)TAU_GAMMA * clamp1000(p->pe_Deg) +
    (uint32_t)TAU_DELTA * clamp1000(p->pe_Stb) +
    (uint32_t)TAU_PSI   * clamp1000(p->pe_TauTx);

  uint16_t tau = (uint16_t)(num / wsum);
  return clamp1000(tau);
}

/* Compute TauTx for THIS node based on local Pi and chosen parent TauTx */
static uint16_t compute_tau_tx(uint16_t E_i, uint16_t InvV_i, uint16_t Deg_i, uint16_t Stb_i, uint16_t parent_tau_tx)
{
  uint32_t wsum = (TAU_ALPHA + TAU_BETA + TAU_GAMMA + TAU_DELTA + TAU_PSI);
  uint32_t num =
    (uint32_t)TAU_ALPHA * E_i +
    (uint32_t)TAU_BETA  * InvV_i +
    (uint32_t)TAU_GAMMA * Deg_i +
    (uint32_t)TAU_DELTA * Stb_i +
    (uint32_t)TAU_PSI   * parent_tau_tx;

  uint16_t tau = (uint16_t)(num / wsum);
  return clamp1000(tau);
}

/* ====== Link features (0..1000) ====== */
static uint16_t rssi_norm(int16_t rssi_dbm)
{
  /* map [-95..-60] => [0..1000] */
  if(rssi_dbm <= -95) return 0;
  if(rssi_dbm >= -60) return 1000;
  return (uint16_t)(((int32_t)rssi_dbm + 95) * 1000 / 35);
}

static uint16_t etx_norm(uint16_t etx_div128)
{
  /* ETX in divisor units; map [1..8] approx */
  if(etx_div128 <= 1 * RPL_DAG_MC_ETX_DIVISOR) return 1000;
  if(etx_div128 >= 8 * RPL_DAG_MC_ETX_DIVISOR) return 0;
  uint32_t x = etx_div128 - 1 * RPL_DAG_MC_ETX_DIVISOR;
  uint32_t span = 7 * RPL_DAG_MC_ETX_DIVISOR;
  return (uint16_t)(1000 - (x * 1000 / span));
}

static uint16_t link_stab_norm(const struct link_stats *s)
{
  if(s == NULL) return 0;
  /* freshness often 0..16 => map to 0..1000 */
  uint16_t f = s->freshness;
  if(f >= 16) return 1000;
  return (uint16_t)(f * 1000 / 16);
}

static uint16_t hops_norm(rpl_parent_t *p)
{
  if(p == NULL || p->dag == NULL || p->dag->instance == NULL) return 0;
  uint16_t inc = p->dag->instance->min_hoprankinc;
  if(inc == 0) return 0;
  uint16_t hops = p->rank / inc;
  if(hops >= 10) return 0;
  return (uint16_t)(1000 - hops * 100);
}

/* ====== Rank / path cost (monotonic) ====== */
static uint16_t parent_link_metric(rpl_parent_t *p)
{
  const struct link_stats *s = rpl_get_parent_link_stats(p);
  if(s == NULL) return 0xFFFF;

  /* Use ETX as base */
  uint16_t etx = s->etx;

  /* Add penalty if RSSI weak */
  int16_t rssi = (s->rssi == 0) ? -100 : s->rssi;
  if(rssi < -90) etx += 2 * RPL_DAG_MC_ETX_DIVISOR;

  /* Add penalty if stale */
#ifdef link_stats_is_fresh
  if(!link_stats_is_fresh(s)) etx += 2 * RPL_DAG_MC_ETX_DIVISOR;
#endif

  return etx;
}

static int parent_has_usable_link(rpl_parent_t *p)
{
  return parent_link_metric(p) != 0xFFFF;
}

static uint16_t parent_path_cost(rpl_parent_t *p)
{
  if(p == NULL) return 0xFFFF;
  uint32_t sum = (uint32_t)p->rank + (uint32_t)parent_link_metric(p);
  return (sum > 0xFFFF) ? 0xFFFF : (uint16_t)sum;
}

static rpl_rank_t rank_via_parent(rpl_parent_t *p)
{
  if(p == NULL || p->dag == NULL || p->dag->instance == NULL) return INFINITE_RANK;

  uint16_t inc = p->dag->instance->min_hoprankinc;
  uint16_t lm  = parent_link_metric(p);
  if(lm == 0xFFFF) return INFINITE_RANK;

  uint32_t rank_inc = (uint32_t)inc * (uint32_t)lm / RPL_DAG_MC_ETX_DIVISOR;
  uint32_t r = (uint32_t)p->rank + rank_inc;
  if(r > INFINITE_RANK) r = INFINITE_RANK;
  return (rpl_rank_t)r;
}

/* ====== DRL-based best_parent ====== */
static rpl_parent_t *best_parent(rpl_parent_t *p1, rpl_parent_t *p2)
{
  if(p1 == NULL) return p2;
  if(p2 == NULL) return p1;

  if(!parent_has_usable_link(p1)) return parent_has_usable_link(p2) ? p2 : NULL;
  if(!parent_has_usable_link(p2)) return parent_has_usable_link(p1) ? p1 : NULL;

  /* Local Pi */
  uint16_t E_i   = rpl_pe_E;
  uint16_t InvV_i= rpl_pe_InvV;
  uint16_t Deg_i = rpl_pe_Deg;
  uint16_t Stb_i = rpl_pe_Stb;

  /* Link stats for each parent */
  const struct link_stats *s1 = rpl_get_parent_link_stats(p1);
  const struct link_stats *s2 = rpl_get_parent_link_stats(p2);

  uint16_t rssi1 = rssi_norm((s1 && s1->rssi) ? s1->rssi : -100);
  uint16_t rssi2 = rssi_norm((s2 && s2->rssi) ? s2->rssi : -100);

  uint16_t etx1  = etx_norm((s1) ? s1->etx : 8 * RPL_DAG_MC_ETX_DIVISOR);
  uint16_t etx2  = etx_norm((s2) ? s2->etx : 8 * RPL_DAG_MC_ETX_DIVISOR);

  uint16_t ls1   = link_stab_norm(s1);
  uint16_t ls2   = link_stab_norm(s2);

  uint16_t h1    = hops_norm(p1);
  uint16_t h2    = hops_norm(p2);

  /* tau_candidate computed from received PE */
  uint16_t tau1 = p1->tau_cand;
  uint16_t tau2 = p2->tau_cand;

  int32_t q1 = drl_score_parent(p1, tau1, rssi1, etx1, ls1, h1, E_i, InvV_i, Deg_i, Stb_i);
  int32_t q2 = drl_score_parent(p2, tau2, rssi2, etx2, ls2, h2, E_i, InvV_i, Deg_i, Stb_i);

  return (q1 >= q2) ? p1 : p2;
}

static rpl_dag_t *best_dag(rpl_dag_t *d1, rpl_dag_t *d2)
{
  if(d1->grounded != d2->grounded) return d1->grounded ? d1 : d2;
  if(d1->preference != d2->preference) return d1->preference > d2->preference ? d1 : d2;
  return d1->rank < d2->rank ? d1 : d2;
}

/* update_metric_container is used here as "periodic update" hook for PE globals */
static void update_metric_container(rpl_instance_t *instance)
{
  rpl_dag_t *dag = instance->current_dag;
  if(dag == NULL) return;

  /* compute local Pi */
  rpl_pe_E    = clamp1000(rpl_residual_energy_norm());
  rpl_pe_InvV = clamp1000(rpl_inv_speed_norm());
  rpl_pe_Deg  = clamp1000(node_degree_norm());
  rpl_pe_Stb  = clamp1000(stability_norm());

  /* parent tau for recursion */
  uint16_t parent_tau = 0;
  if(dag->rank != ROOT_RANK(instance) && dag->preferred_parent != NULL) {
    parent_tau = clamp1000(dag->preferred_parent->pe_TauTx);
  }

  rpl_pe_TauTx = compute_tau_tx(rpl_pe_E, rpl_pe_InvV, rpl_pe_Deg, rpl_pe_Stb, parent_tau);

  /* Keep MC as ETX (optional). If you want MC disabled, you can keep NONE. */
  instance->mc.type = RPL_DAG_MC_ETX;
  instance->mc.flags = 0;
  instance->mc.aggr = RPL_DAG_MC_AGGR_ADDITIVE;
  instance->mc.prec = 0;
  instance->mc.length = sizeof(instance->mc.obj.etx);
  instance->mc.obj.etx = (dag->rank == ROOT_RANK(instance)) ? dag->rank : parent_path_cost(dag->preferred_parent);
}

static void reset(rpl_dag_t *dag)
{
  (void)dag;
  parent_switches = 0;
  drl_init();
}

/* Choose your custom OCP */
#define RPL_OCP_DRL 0xB7

rpl_of_t rpl_of_drl = {
  reset,
#if RPL_WITH_DAO_ACK
  NULL,
#endif
  parent_link_metric,
  parent_has_usable_link,
  parent_path_cost,
  rank_via_parent,
  best_parent,
  best_dag,
  update_metric_container,
  RPL_OCP_DRL
};

